package dem.corp.androidmessenger.bottomnav.chats;

import static androidx.fragment.app.FragmentManager.TAG;

import static dem.corp.androidmessenger.utils.ChatUtil.generateChatId;

import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import dem.corp.androidmessenger.chats.Chat;
import dem.corp.androidmessenger.chats.ChatsAdapter;
import dem.corp.androidmessenger.databinding.FragmentChatsBinding;
import dem.corp.androidmessenger.utils.ChatUtil;

public class ChatsFragment extends Fragment {
    private FragmentChatsBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentChatsBinding.inflate(inflater, container, false);

        loadChats();

        return binding.getRoot();
    }

    @SuppressLint("RestrictedApi")
    private void loadChats(){

        Log.w(TAG, "Error getting documents. 222");
        ArrayList<Chat> chats = new ArrayList<>();

        String uid = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
        Log.w(TAG, "Error getting documents. 222 uid =" + uid);
        FirebaseDatabase.getInstance().getReference().addListenerForSingleValueEvent(new ValueEventListener() {
           // @SuppressLint("RestrictedApi")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String chatsStr = Objects.requireNonNull(snapshot.child("Users").child(uid).child("chats").getValue()).toString();
                Log.w(TAG, "Error getting documents. 2222 chatsStr" + chatsStr);

                String[] chatsIds = chatsStr.split(",");

             //   String s = "chatsStr-ODqP1-1G1AtcwnrDVLk, ZqnkGaeyk3UkRLRJH8Qh1tQiF7d2";
               // String[] a = s.split(", ");
                for (String v : chatsIds) {
                    System.out.println(v);
                    Log.w(TAG, "Error getting documents. 2222 chatsIds=" + v);
                }


                //ChatUtil.createChat("ZqnkGaeyk3UkRLRJH8Qh1tQiF7d2");
               // FirebaseDatabase.getInstance().getReference().child("Users").child("mdlfnx5Bo4dbpKOjwmUxaiyJzAY2")
                 //       .child("chats").setValue(chatsUpd);
                String uid = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
                Log.w(TAG, "Error getting documents. 2222 chats uid=" + uid);

                //добавим тестовый чат

               // String chatIdmyTest = generateChatId(uid, "1Sx2FCTKDcdfjhztPtTbWgSxFZP2");
                String chatIdmyTest =  "ZqnkGaeyk3UkRLRJH8Qh1tQiF7d3";


                HashMap<String, String> chatInfo = new HashMap<>();
                chatInfo.put("user1", uid);
                chatInfo.put("user2", "1Sx2FCTKDcdfjhztPtTbWgSxFZP2");
                FirebaseDatabase.getInstance().getReference().child("Chats").child(chatIdmyTest)
                        .setValue(chatInfo);



               // String chatCurrentId = "ZqnkGaeyk3UkRLRJH8Qh1tQiF7d2";
               // String chatId = generateChatId(uid, user.uid);
               // FirebaseDatabase.getInstance().getReference().child("Chats").child(chatCurrentId)
                //        .setValue(chatInfo);

                if (chatsIds.length==0) return;

                for (String chatId : chatsIds){
                    DataSnapshot chatSnapshot = snapshot.child("Chats").child(chatId);
                 //   DataSnapshot chatSnapshot = snapshot.child("Chats").child("ZqnkGaeyk3UkRLRJH8Qh1tQiF7d2");
                    String userId1 = Objects.requireNonNull(chatSnapshot.child("user1").getValue()).toString();
                    Log.w(TAG, "Error getting documents. 2222 userId1=" + userId1);
                    String userId2 = Objects.requireNonNull(chatSnapshot.child("user2").getValue()).toString();
                    Log.w(TAG, "Error getting documents. 2222 userId2=" + userId2);


                    String chatUserId = (uid.equals(userId1)) ? userId2 : userId1;
                    Log.w(TAG, "Error getting documents. 2222 chatUserId=" + chatUserId);
                    String chatName = Objects.requireNonNull(snapshot.child("Users").child(chatUserId).child("username").getValue()).toString();

                    Chat chat = new Chat(chatId, chatName, userId1, userId2);
                    chats.add(chat);
                }

                binding.chatsRv.setLayoutManager(new LinearLayoutManager(getContext()));
                binding.chatsRv.setAdapter(new ChatsAdapter(chats));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Failed to get user chats", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
