# Описание

*Android Messenger* - это простой open source мессенджер, создание которого было полностью показано на [youtube канале](https://www.youtube.com/@programmerc1178).

- Мессенджер написан полностью на Java
- Для верстки используется XML
- В качестве языка для файлов сборки используется Groovy
- Для системы аутентификации, БД и хранилища - Firebase (Authentication, Realtime Database, Storage)
